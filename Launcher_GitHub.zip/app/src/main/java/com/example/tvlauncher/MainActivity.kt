package com.example.tvlauncher

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.tv.material3.Card
import androidx.tv.material3.CardDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppInfo(
    val label: String,
    val component: ComponentName,
    val icon: ImageBitmap
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherScreen()
            }
        }
    }
}

@Composable
fun LauncherScreen() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadApps(context) }
    }

    fun launch(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            component = app.component
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)))
            )
    ) {
        Column(Modifier.fillMaxSize().padding(start = 16.dp, end = 16.dp, top = 40.dp, bottom = 20.dp)) {
            // Widgets row (macOS style cards)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ClockWidget(Modifier.width(240.dp))
                WeatherWidget(Modifier.width(160.dp))
                NotesWidget(Modifier.width(200.dp))
            }

            Spacer(Modifier.height(24.dp))
            Text("Apps", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            Spacer(Modifier.height(12.dp))

            // App grid
            LazyVerticalGrid(
                columns = GridCells.Adaptive(80.dp),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                items(apps) { app -> AppTile(app) { launch(app) } }
            }

            Spacer(Modifier.height(12.dp))

            // Dock (ChromeOS shelf style)
            Row(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .background(Color(0x33FFFFFF), RoundedCornerShape(28.dp))
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                apps.take(5).forEach { app -> DockIcon(app) { launch(app) } }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun WidgetCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Box(
        modifier
            .height(130.dp)
            .background(Color(0x33FFFFFF), RoundedCornerShape(20.dp))
            .padding(20.dp)
    ) {
        Column(verticalArrangement = Arrangement.Center, content = content)
    }
}

@Composable
fun ClockWidget(modifier: Modifier = Modifier) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) { now = Date(); delay(1000) }
    }
    WidgetCard(modifier) {
        Text(
            SimpleDateFormat("hh:mm a", Locale.getDefault()).format(now),
            fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White
        )
        Text(
            SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now),
            fontSize = 18.sp, color = Color(0xFFCCCCCC)
        )
    }
}

@Composable
fun WeatherWidget(modifier: Modifier = Modifier) {
    // Demo data. Connect a weather API (e.g. Open-Meteo) later.
    WidgetCard(modifier) {
        Text("28°C", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Sunny (demo)", fontSize = 18.sp, color = Color(0xFFCCCCCC))
    }
}

@Composable
fun NotesWidget(modifier: Modifier = Modifier) {
    WidgetCard(modifier) {
        Text("Notes", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
        Text("Add your widget here", fontSize = 16.sp, color = Color(0xFFCCCCCC))
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun AppTile(app: AppInfo, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = CardDefaults.shape(RoundedCornerShape(16.dp)),
        scale = CardDefaults.scale(focusedScale = 1.1f)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(app.icon, app.label, Modifier.size(56.dp))
            Spacer(Modifier.height(6.dp))
            Text(app.label, fontSize = 14.sp, maxLines = 1)
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun DockIcon(app: AppInfo, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = CardDefaults.shape(RoundedCornerShape(14.dp)),
        scale = CardDefaults.scale(focusedScale = 1.25f)
    ) {
        Image(app.icon, app.label, Modifier.padding(8.dp).size(44.dp))
    }
}

fun loadApps(context: android.content.Context): List<AppInfo> {
    val pm = context.packageManager
    val result = LinkedHashMap<String, AppInfo>()
    listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER).forEach { category ->
        val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
        pm.queryIntentActivities(intent, 0).forEach { ri ->
            val pkg = ri.activityInfo.packageName
            if (pkg == context.packageName || result.containsKey(pkg)) return@forEach
            val bmp = ri.loadIcon(pm).toBitmap(128, 128).asImageBitmap()
            result[pkg] = AppInfo(
                ri.loadLabel(pm).toString(),
                ComponentName(pkg, ri.activityInfo.name),
                bmp
            )
        }
    }
    return result.values.sortedBy { it.label.lowercase() }
}
