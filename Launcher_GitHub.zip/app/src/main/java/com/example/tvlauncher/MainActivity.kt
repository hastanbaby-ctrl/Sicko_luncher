package com.example.tvlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppInfo(val label: String, val component: ComponentName, val icon: ImageBitmap)

data class LTheme(
    val name: String,
    val bg: List<Color>,
    val accent: Color,
    val hill: Color,
    val text: Color
)

val Themes = listOf(
    LTheme("Ocean", listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)), Color(0xFF4FC3F7), Color(0xFF0B1A22), Color.White),
    LTheme("Sunset", listOf(Color(0xFF2B1055), Color(0xFF7B337E), Color(0xFFE5707E)), Color(0xFFFFB86B), Color(0xFF2A0E3D), Color.White),
    LTheme("Aurora", listOf(Color(0xFF0B3D2E), Color(0xFF1B6B5A), Color(0xFF2E3A8C)), Color(0xFF7CFFCB), Color(0xFF062A20), Color.White),
    LTheme("Midnight", listOf(Color(0xFF000000), Color(0xFF111827), Color(0xFF1F2937)), Color(0xFFA78BFA), Color(0xFF000000), Color.White),
    LTheme("Light", listOf(Color(0xFFE0EAFC), Color(0xFFCFDEF3), Color(0xFFB6CCE8)), Color(0xFF2563EB), Color(0xFF9FB8DA), Color(0xFF111827))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherRoot()
            }
        }
    }
}

// ---------- helpers ----------

fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp)): Modifier = this
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.30f), Color.White.copy(alpha = 0.10f))
        )
    )
    .border(1.dp, Color.White.copy(alpha = 0.35f), shape)

@Composable
fun GlowBox(
    modifier: Modifier = Modifier,
    accent: Color,
    shape: Shape = RoundedCornerShape(20.dp),
    focusScale: Float = 1.12f,
    fill: Color = Color.Transparent,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) focusScale else 1f, label = "focusScale")
    Box(
        modifier
            .scale(scale)
            .onFocusChanged { focused = it.isFocused }
            .then(if (focused) Modifier.border(3.dp, accent, shape) else Modifier)
            .clip(shape)
            .background(fill)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        content = content
    )
}

@Composable
fun rememberNow(): Date {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) { now = Date(); delay(1000) }
    }
    return now
}

fun fmtTime(d: Date, h24: Boolean, sec: Boolean): String {
    val p = (if (h24) "HH:mm" else "hh:mm") + (if (sec) ":ss" else "")
    return SimpleDateFormat(p, Locale.getDefault()).format(d)
}

fun safeStart(context: Context, intent: Intent) {
    try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        // this screen is not available on this device
    }
}

fun loadApps(context: Context): List<AppInfo> {
    val pm = context.packageManager
    val result = LinkedHashMap<String, AppInfo>()
    listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER).forEach { category ->
        val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
        pm.queryIntentActivities(intent, 0).forEach { ri ->
            val pkg = ri.activityInfo.packageName
            if (pkg == context.packageName || result.containsKey(pkg)) return@forEach
            val bmp = ri.loadIcon(pm).toBitmap(128, 128).asImageBitmap()
            result[pkg] = AppInfo(
                ri.loadLabel(pm).toString(),
                ComponentName(pkg, ri.activityInfo.name),
                bmp
            )
        }
    }
    return result.values.sortedBy { it.label.lowercase() }
}

// ---------- root ----------

@Composable
fun LauncherRoot() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("launcher", Context.MODE_PRIVATE) }
    var themeIdx by remember { mutableStateOf(prefs.getInt("theme", 0).coerceIn(0, Themes.size - 1)) }
    var h24 by remember { mutableStateOf(prefs.getBoolean("h24", false)) }
    var seconds by remember { mutableStateOf(prefs.getBoolean("sec", false)) }
    var screen by remember { mutableStateOf(0) } // 0 home, 1 apps, 2 settings
    var panel by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    val theme = Themes[themeIdx]

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadApps(context) }
    }

    fun launchApp(app: AppInfo) {
        safeStart(
            context,
            Intent(Intent.ACTION_MAIN).apply { component = app.component }
        )
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(theme.bg))
            .drawBehind {
                val r = size.minDimension * 0.7f
                val c1 = Offset(size.width * 0.15f, size.height * 0.2f)
                val c2 = Offset(size.width * 0.85f, size.height * 0.85f)
                drawCircle(
                    Brush.radialGradient(listOf(theme.accent.copy(alpha = 0.35f), Color.Transparent), center = c1, radius = r),
                    radius = r, center = c1
                )
                drawCircle(
                    Brush.radialGradient(listOf(theme.accent.copy(alpha = 0.25f), Color.Transparent), center = c2, radius = r),
                    radius = r, center = c2
                )
            }
    ) {
        Row(Modifier.fillMaxSize().padding(12.dp)) {
            Sidebar(theme, screen, { screen = it }, { panel = !panel })
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).fillMaxHeight()) {
                StatusBar(theme, h24)
                Spacer(Modifier.height(8.dp))
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (screen) {
                        0 -> HomeScreen(theme, apps, h24, seconds) { launchApp(it) }
                        1 -> AppsScreen(theme, apps) { launchApp(it) }
                        else -> SettingsScreen(
                            theme, themeIdx,
                            { themeIdx = it; prefs.edit().putInt("theme", it).apply() },
                            h24, { h24 = !h24; prefs.edit().putBoolean("h24", h24).apply() },
                            seconds, { seconds = !seconds; prefs.edit().putBoolean("sec", seconds).apply() }
                        )
                    }
                }
            }
        }
        AnimatedVisibility(
            visible = panel,
            modifier = Modifier.align(Alignment.CenterEnd),
            enter = slideInHorizontally { it } + fadeIn(),
            exit = slideOutHorizontally { it } + fadeOut()
        ) {
            ControlCenter(theme) { panel = false }
        }
    }
}

// ---------- sidebar and status bar ----------

@Composable
fun Sidebar(theme: LTheme, screen: Int, onScreen: (Int) -> Unit, onPanel: () -> Unit) {
    Column(
        Modifier
            .fillMaxHeight()
            .width(72.dp)
            .glass(RoundedCornerShape(36.dp))
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
    ) {
        listOf("🏠", "🔲", "⚙️").forEachIndexed { i, e ->
            NavItem(e, screen == i, theme.accent) { onScreen(i) }
        }
        NavItem("🎛️", false, theme.accent) { onPanel() }
    }
}

@Composable
fun NavItem(icon: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    GlowBox(
        modifier = Modifier.size(48.dp),
        accent = accent,
        shape = CircleShape,
        focusScale = 1.2f,
        fill = if (selected) accent.copy(alpha = 0.45f) else Color.Transparent,
        onClick = onClick
    ) {
        Text(icon, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
    }
}

@Composable
fun StatusBar(theme: LTheme, h24: Boolean) {
    val context = LocalContext.current
    val now = rememberNow()
    var battery by remember { mutableStateOf(-1) }
    var expanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scl = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            battery = if (lvl >= 0 && scl > 0) lvl * 100 / scl else -1
            delay(30000)
        }
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Box(Modifier.weight(1f)) {
            Text(
                SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(now),
                color = theme.text.copy(alpha = 0.8f), fontSize = 13.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        // Dynamic Island
        GlowBox(
            modifier = Modifier.animateContentSize(),
            accent = theme.accent,
            shape = RoundedCornerShape(24.dp),
            focusScale = 1.05f,
            fill = Color.Black,
            onClick = { expanded = !expanded }
        ) {
            Column(
                Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("● " + fmtTime(now, h24, false), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                if (expanded) {
                    Text("🔔 Notifications (demo)", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("🎵 Media (demo)", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
        }
        Box(Modifier.weight(1f), contentAlignment = Alignment.TopEnd) {
            Text(
                "📶 " + (if (battery >= 0) "🔋 $battery%" else ""),
                color = theme.text.copy(alpha = 0.8f), fontSize = 13.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

// ---------- screens ----------

@Composable
fun HomeScreen(theme: LTheme, apps: List<AppInfo>, h24: Boolean, seconds: Boolean, onOpen: (AppInfo) -> Unit) {
    val now = rememberNow()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // big clock, half hidden behind a hill
        BoxWithConstraints(Modifier.fillMaxWidth().height(200.dp)) {
            val t = fmtTime(now, h24, seconds)
            val fs = (maxWidth.value / t.length * 1.7f).coerceIn(40f, 120f)
            Text(
                t,
                modifier = Modifier.align(Alignment.Center),
                color = theme.text.copy(alpha = 0.9f),
                fontSize = fs.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false,
                textAlign = TextAlign.Center
            )
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val p = Path().apply {
                    moveTo(0f, h * 0.60f)
                    cubicTo(w * 0.25f, h * 0.42f, w * 0.55f, h * 0.75f, w, h * 0.52f)
                    lineTo(w, h)
                    lineTo(0f, h)
                    close()
                }
                drawPath(p, Brush.verticalGradient(listOf(theme.hill.copy(alpha = 0.95f), theme.bg.last())))
            }
            Text(
                SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
                color = theme.text.copy(alpha = 0.85f),
                fontSize = 16.sp
            )
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            InfoCard(Modifier.weight(1f), "Weather", "28°C Sunny (demo)", theme.text)
            InfoCard(Modifier.weight(1f), "Notes", "Your note here (demo)", theme.text)
        }
        Spacer(Modifier.height(20.dp))
        // dock
        Row(
            Modifier.glass(RoundedCornerShape(28.dp)).padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            apps.take(6).forEach { app ->
                GlowBox(
                    modifier = Modifier.size(52.dp),
                    accent = theme.accent,
                    shape = RoundedCornerShape(14.dp),
                    focusScale = 1.45f,
                    onClick = { onOpen(app) }
                ) {
                    Image(app.icon, app.label, Modifier.fillMaxSize().padding(4.dp))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun InfoCard(modifier: Modifier, title: String, line: String, color: Color) {
    Column(modifier.glass().padding(16.dp)) {
        Text(title, color = color, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text(line, color = color.copy(alpha = 0.7f), fontSize = 14.sp)
    }
}

@Composable
fun AppsScreen(theme: LTheme, apps: List<AppInfo>, onOpen: (AppInfo) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("Apps", color = theme.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(96.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(8.dp)
        ) {
            items(apps) { app ->
                GlowBox(
                    accent = theme.accent,
                    shape = RoundedCornerShape(18.dp),
                    focusScale = 1.1f,
                    fill = Color.White.copy(alpha = 0.14f),
                    onClick = { onOpen(app) }
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(app.icon, app.label, Modifier.size(52.dp))
                        Spacer(Modifier.height(6.dp))
                        Text(app.label, color = theme.text, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    theme: LTheme,
    themeIdx: Int,
    onTheme: (Int) -> Unit,
    h24: Boolean,
    onH24: () -> Unit,
    seconds: Boolean,
    onSeconds: () -> Unit
) {
    val context = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", color = theme.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text("Theme", color = theme.text.copy(alpha = 0.8f), fontSize = 14.sp)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Themes.forEachIndexed { i, t ->
                GlowBox(
                    accent = theme.accent,
                    shape = RoundedCornerShape(16.dp),
                    focusScale = 1.08f,
                    fill = if (i == themeIdx) theme.accent.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.14f),
                    onClick = { onTheme(i) }
                ) {
                    Text(
                        t.name, color = theme.text, fontSize = 15.sp,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                    )
                }
            }
        }
        ToggleRow("24-hour clock", h24, theme.accent, theme.text, onH24)
        ToggleRow("Show seconds", seconds, theme.accent, theme.text, onSeconds)
        GlowBox(
            modifier = Modifier.fillMaxWidth(),
            accent = theme.accent,
            shape = RoundedCornerShape(16.dp),
            focusScale = 1.03f,
            fill = Color.White.copy(alpha = 0.14f),
            onClick = { safeStart(context, Intent(Settings.ACTION_SETTINGS)) }
        ) {
            Text("Open Android settings", color = theme.text, fontSize = 16.sp, modifier = Modifier.padding(16.dp))
        }
    }
}

@Composable
fun ToggleRow(label: String, on: Boolean, accent: Color, color: Color, onToggle: () -> Unit) {
    GlowBox(
        modifier = Modifier.fillMaxWidth(),
        accent = accent,
        shape = RoundedCornerShape(16.dp),
        focusScale = 1.03f,
        fill = Color.White.copy(alpha = 0.14f),
        onClick = onToggle
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = color, fontSize = 16.sp)
            Text(
                if (on) "ON" else "OFF",
                color = if (on) accent else color.copy(alpha = 0.5f),
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// ---------- control center ----------

@Composable
fun ControlCenter(theme: LTheme, onClose: () -> Unit) {
    val context = LocalContext.current
    fun volume(direction: Int) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        } catch (e: Exception) {
        }
    }
    Column(
        Modifier
            .padding(12.dp)
            .width(280.dp)
            .glass(RoundedCornerShape(28.dp))
            .background(Color.Black.copy(alpha = 0.25f))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Control Center", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CCTile("📶", "Wi-Fi", Modifier.weight(1f), theme.accent) { safeStart(context, Intent(Settings.ACTION_WIFI_SETTINGS)) }
            CCTile("🔵", "Bluetooth", Modifier.weight(1f), theme.accent) { safeStart(context, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CCTile("🖥️", "Display", Modifier.weight(1f), theme.accent) { safeStart(context, Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
            CCTile("🔊", "Sound", Modifier.weight(1f), theme.accent) { safeStart(context, Intent(Settings.ACTION_SOUND_SETTINGS)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CCTile("🔉", "Vol -", Modifier.weight(1f), theme.accent) { volume(AudioManager.ADJUST_LOWER) }
            CCTile("🔊", "Vol +", Modifier.weight(1f), theme.accent) { volume(AudioManager.ADJUST_RAISE) }
        }
        CCTile("⚙️", "All settings", Modifier.fillMaxWidth(), theme.accent) { safeStart(context, Intent(Settings.ACTION_SETTINGS)) }
        CCTile("✖️", "Close", Modifier.fillMaxWidth(), theme.accent) { onClose() }
    }
}

@Composable
fun CCTile(icon: String, label: String, modifier: Modifier, accent: Color, onClick: () -> Unit) {
    GlowBox(
        modifier = modifier.height(64.dp),
        accent = accent,
        shape = RoundedCornerShape(18.dp),
        focusScale = 1.06f,
        fill = Color.White.copy(alpha = 0.18f),
        onClick = onClick
    ) {
        Column(
            Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(icon, fontSize = 20.sp)
            Text(label, color = Color.White, fontSize = 12.sp)
        }
    }
}
