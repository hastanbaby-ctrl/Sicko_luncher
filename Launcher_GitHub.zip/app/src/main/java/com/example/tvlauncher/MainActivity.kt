package com.example.tvlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.BatteryFull
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Settings as SettingsIcon
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppInfo(val label: String, val component: ComponentName, val icon: ImageBitmap)

data class LTheme(
    val name: String,
    val bg: List<Color>,
    val accent: Color,
    val hill: Color,
    val text: Color
)

val Themes = listOf(
    LTheme("Ocean", listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)), Color(0xFF4FC3F7), Color(0xFF0B1A22), Color.White),
    LTheme("Sunset", listOf(Color(0xFF2B1055), Color(0xFF7B337E), Color(0xFFE5707E)), Color(0xFFFFB86B), Color(0xFF2A0E3D), Color.White),
    LTheme("Aurora", listOf(Color(0xFF0B3D2E), Color(0xFF1B6B5A), Color(0xFF2E3A8C)), Color(0xFF7CFFCB), Color(0xFF062A20), Color.White),
    LTheme("Midnight", listOf(Color(0xFF000000), Color(0xFF111827), Color(0xFF1F2937)), Color(0xFFA78BFA), Color(0xFF000000), Color.White),
    LTheme("Light", listOf(Color(0xFFE0EAFC), Color(0xFFCFDEF3), Color(0xFFB6CCE8)), Color(0xFF2563EB), Color(0xFF9FB8DA), Color(0xFF111827))
)

val WallpaperNames = listOf(
    "Theme", "Snowy Peaks", "Ocean Sunset", "Desert Canyon",
    "Neon City", "Moonlit Lake", "Layered Ridges", "Planet Horizon"
)

val WallRes = listOf(
    0, R.drawable.wp1_snowy, R.drawable.wp2_ocean, R.drawable.wp3_canyon,
    R.drawable.wp4_neon, R.drawable.wp5_lake, R.drawable.wp6_ridges, R.drawable.wp7_planet
)

val CutRes = listOf(
    0, R.drawable.wp1_snowy_cut, R.drawable.wp2_ocean_cut, R.drawable.wp3_canyon_cut,
    R.drawable.wp4_neon_cut, R.drawable.wp5_lake_cut, R.drawable.wp6_ridges_cut, R.drawable.wp7_planet_cut
)

val LocalGlass = compositionLocalOf { 1f }

class Cfg(private val prefs: SharedPreferences) {
    var themeIdx by mutableStateOf(prefs.getInt("theme", 0).coerceIn(0, Themes.size - 1))
    var h24 by mutableStateOf(prefs.getBoolean("h24", false))
    var seconds by mutableStateOf(prefs.getBoolean("sec", false))
    var wall by mutableStateOf(prefs.getInt("wall2", 1).coerceIn(-1, WallpaperNames.size - 1))
    var iconStyle by mutableStateOf(prefs.getInt("iconStyle", 0).coerceIn(0, 2))
    var iconShape by mutableStateOf(prefs.getInt("iconShape", 0).coerceIn(0, 1))
    var iconSize by mutableStateOf(prefs.getInt("iconSize", 1).coerceIn(0, 2))
    var glass by mutableStateOf(prefs.getInt("glass", 1).coerceIn(0, 2))
    var labels by mutableStateOf(prefs.getBoolean("labels", true))
    var dockCount by mutableStateOf(prefs.getInt("dock", 6).coerceIn(4, 7))
    var widgets by mutableStateOf(prefs.getBoolean("widgets", true))
    var depth by mutableStateOf(prefs.getBoolean("depth", true))
    var clockStyle by mutableStateOf(prefs.getInt("clockStyle", 0).coerceIn(0, 1))
    var clockPos by mutableStateOf(prefs.getInt("clockPos", 1).coerceIn(0, 2))
    var clockSize by mutableStateOf(prefs.getInt("clockSize", 1).coerceIn(0, 2))

    fun change(block: Cfg.() -> Unit) {
        block()
        prefs.edit()
            .putInt("theme", themeIdx)
            .putBoolean("h24", h24)
            .putBoolean("sec", seconds)
            .putInt("wall2", wall)
            .putInt("iconStyle", iconStyle)
            .putInt("iconShape", iconShape)
            .putInt("iconSize", iconSize)
            .putInt("glass", glass)
            .putBoolean("labels", labels)
            .putInt("dock", dockCount)
            .putBoolean("widgets", widgets)
            .putBoolean("depth", depth)
            .putInt("clockStyle", clockStyle)
            .putInt("clockPos", clockPos)
            .putInt("clockSize", clockSize)
            .apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherRoot()
            }
        }
    }
}

// ---------- helpers ----------

@Composable
fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp)): Modifier {
    val k = LocalGlass.current
    return this
        .clip(shape)
        .background(
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.30f * k), Color.White.copy(alpha = 0.10f * k))
            )
        )
        .border(1.dp, Color.White.copy(alpha = (0.35f * k).coerceAtMost(0.9f)), shape)
}

@Composable
fun GlowBox(
    modifier: Modifier = Modifier,
    accent: Color,
    shape: Shape = RoundedCornerShape(20.dp),
    focusScale: Float = 1.12f,
    fill: Color = Color.Transparent,
    lens: Boolean = false,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) focusScale else 1f, label = "focusScale")
    Box(
        modifier
            .scale(scale)
            .onFocusChanged { focused = it.isFocused }
            .then(if (focused && !lens) Modifier.border(3.dp, accent, shape) else Modifier)
            .clip(shape)
            .background(if (focused && lens) Color.White.copy(alpha = 0.22f) else fill)
            .then(if (focused && lens) Modifier.border(2.dp, Color.White.copy(alpha = 0.85f), shape) else Modifier)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        content = content
    )
}

@Composable
fun Ico(icon: ImageVector, tint: Color, size: Dp = 22.dp, modifier: Modifier = Modifier) {
    Image(icon, null, modifier.size(size), colorFilter = ColorFilter.tint(tint))
}

@Composable
fun rememberNow(): Date {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) { now = Date(); delay(1000) }
    }
    return now
}

@Composable
fun rememberRes(resId: Int, sample: Int): ImageBitmap? {
    val context = LocalContext.current
    val st = produceState<ImageBitmap?>(null, resId, sample) {
        value = withContext(Dispatchers.IO) {
            try {
                val o = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeResource(context.resources, resId, o)?.asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
    return st.value
}

fun fmtTime(d: Date, h24: Boolean, sec: Boolean): String {
    val p = (if (h24) "HH:mm" else "hh:mm") + (if (sec) ":ss" else "")
    return SimpleDateFormat(p, Locale.getDefault()).format(d)
}

fun safeStart(context: Context, intent: Intent) {
    try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        // this screen is not available on this device
    }
}

fun loadApps(context: Context): List<AppInfo> {
    val pm = context.packageManager
    val result = LinkedHashMap<String, AppInfo>()
    listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER).forEach { category ->
        val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
        pm.queryIntentActivities(intent, 0).forEach { ri ->
            val pkg = ri.activityInfo.packageName
            if (pkg == context.packageName || result.containsKey(pkg)) return@forEach
            val bmp = ri.loadIcon(pm).toBitmap(128, 128).asImageBitmap()
            result[pkg] = AppInfo(
                ri.loadLabel(pm).toString(),
                ComponentName(pkg, ri.activityInfo.name),
                bmp
            )
        }
    }
    return result.values.sortedBy { it.label.lowercase() }
}

fun iconShape(cfg: Cfg, size: Dp): Shape =
    if (cfg.iconShape == 1) CircleShape else RoundedCornerShape(size * 0.28f)

fun dockSize(cfg: Cfg): Dp = listOf(44.dp, 52.dp, 60.dp)[cfg.iconSize]
fun gridSize(cfg: Cfg): Dp = listOf(48.dp, 58.dp, 70.dp)[cfg.iconSize]

// ---------- theme wallpaper (used when no image wallpaper is chosen) ----------

fun DrawScope.blob(color: Color, cx: Float, cy: Float, r: Float, alpha: Float) {
    drawCircle(
        Brush.radialGradient(
            listOf(color.copy(alpha = alpha), Color.Transparent),
            center = Offset(cx, cy),
            radius = r
        ),
        radius = r,
        center = Offset(cx, cy)
    )
}

fun Modifier.wallpaper(theme: LTheme): Modifier = this
    .background(Brush.linearGradient(theme.bg))
    .drawBehind {
        val r = size.minDimension * 0.7f
        blob(theme.accent, size.width * 0.15f, size.height * 0.2f, r, 0.35f)
        blob(theme.accent, size.width * 0.85f, size.height * 0.85f, r, 0.25f)
    }

fun DrawScope.drawHills(theme: LTheme) {
    val w = size.width
    val h = size.height
    val a = Path().apply {
        moveTo(0f, h * 0.55f)
        cubicTo(w * 0.25f, h * 0.36f, w * 0.55f, h * 0.70f, w, h * 0.42f)
        lineTo(w, h)
        lineTo(0f, h)
        close()
    }
    drawPath(a, theme.hill.copy(alpha = 0.95f))
}

@Composable
fun HillsLayer(theme: LTheme) {
    Canvas(Modifier.fillMaxSize()) { drawHills(theme) }
}

@Composable
fun ClockLayer(theme: LTheme, cfg: Cfg) {
    val now = rememberNow()
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val t = fmtTime(now, cfg.h24, cfg.seconds)
        val tall = cfg.clockStyle == 0
        val posF = listOf(0.24f, 0.30f, 0.38f)[cfg.clockPos]
        val sizeF = listOf(0.8f, 1f, 1.2f)[cfg.clockSize]
        val fs = ((maxWidth.value / t.length) * (if (tall) 1.9f else 1.7f) * sizeF).coerceIn(40f, 160f)
        val top = maxOf(40.dp, maxHeight * posF - (fs * 0.6f).dp - 20.dp)
        Column(
            Modifier.align(Alignment.TopCenter).offset(y = top),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now),
                color = theme.text.copy(alpha = 0.85f),
                fontSize = 16.sp
            )
            val clockMod = if (tall) {
                Modifier
                    .graphicsLayer(scaleX = 0.82f, scaleY = 1.45f)
                    .alpha(0.99f)
                    .drawWithContent {
                        drawContent()
                        drawRect(
                            Brush.verticalGradient(listOf(Color.White, Color.White.copy(alpha = 0.35f))),
                            blendMode = BlendMode.DstIn
                        )
                    }
            } else Modifier
            Text(
                t,
                modifier = clockMod,
                color = theme.text.copy(alpha = 0.92f),
                fontSize = fs.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ---------- glass app icon ----------

@Composable
fun AppIcon(app: AppInfo, cfg: Cfg, accent: Color, size: Dp, modifier: Modifier = Modifier) {
    val k = LocalGlass.current
    val shape = iconShape(cfg, size)
    if (cfg.iconStyle == 2) {
        Image(app.icon, app.label, modifier.size(size).clip(shape))
    } else {
        val tint = if (cfg.iconStyle == 1) accent.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.16f * k)
        Box(
            modifier
                .size(size)
                .clip(shape)
                .background(tint)
                .border(1.dp, Color.White.copy(alpha = (0.45f * k).coerceAtMost(0.9f)), shape)
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.5f)
                    .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f * k), Color.Transparent)))
            )
            Image(
                app.icon, app.label,
                Modifier
                    .align(Alignment.Center)
                    .size(size * 0.66f)
                    .clip(RoundedCornerShape(size * 0.18f))
            )
        }
    }
}

// ---------- root ----------

fun loadFileBitmap(context: Context, name: String): ImageBitmap? {
    return try {
        val f = File(context.filesDir, name)
        if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
    } catch (e: Exception) {
        null
    }
}

fun saveFromUri(context: Context, uri: android.net.Uri, name: String, png: Boolean): Boolean {
    return try {
        val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        if (bmp == null) {
            false
        } else {
            val maxW = 1920
            val scaled = if (bmp.width > maxW) {
                Bitmap.createScaledBitmap(bmp, maxW, bmp.height * maxW / bmp.width, true)
            } else bmp
            File(context.filesDir, name).outputStream().use {
                if (png) scaled.compress(Bitmap.CompressFormat.PNG, 100, it)
                else scaled.compress(Bitmap.CompressFormat.JPEG, 90, it)
            }
            true
        }
    } catch (e: Exception) {
        false
    }
}

@Composable
fun LauncherRoot() {
    val context = LocalContext.current
    val cfg = remember { Cfg(context.getSharedPreferences("launcher", Context.MODE_PRIVATE)) }
    var screen by remember { mutableStateOf(0) } // 0 home, 1 apps, 2 settings
    var panel by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var wallBmp by remember { mutableStateOf<ImageBitmap?>(null) }
    var cutBmp by remember { mutableStateOf<ImageBitmap?>(null) }
    var wallVer by remember { mutableStateOf(0) }
    var cutVer by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                if (saveFromUri(context, uri, "wall.jpg", false)) {
                    cfg.change { wall = -1 }
                    wallVer++
                }
            }
        }
    }
    val cutPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                if (saveFromUri(context, uri, "cutout.png", true)) {
                    cutVer++
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadApps(context) }
    }
    LaunchedEffect(wallVer) {
        wallBmp = withContext(Dispatchers.IO) { loadFileBitmap(context, "wall.jpg") }
    }
    LaunchedEffect(cutVer) {
        cutBmp = withContext(Dispatchers.IO) { loadFileBitmap(context, "cutout.png") }
    }

    val builtBg = rememberRes(if (cfg.wall in 1..7) WallRes[cfg.wall] else 0, 1)
    val builtCut = rememberRes(if (cfg.wall in 1..7) CutRes[cfg.wall] else 0, 1)
    val bgImg: ImageBitmap? = if (cfg.wall in 1..7) builtBg else if (cfg.wall < 0) wallBmp else null
    val cutImg: ImageBitmap? = if (cfg.wall in 1..7) builtCut else if (cfg.wall < 0) cutBmp else null

    val base = Themes[cfg.themeIdx]
    val darkWall = bgImg != null
    val theme = if (darkWall) {
        base.copy(text = Color.White, hill = Color.Black.copy(alpha = 0.45f), bg = listOf(Color.Black.copy(alpha = 0.55f)))
    } else base
    val glassK = listOf(0.6f, 1f, 1.5f)[cfg.glass]

    fun launchApp(app: AppInfo) {
        safeStart(context, Intent(Intent.ACTION_MAIN).apply { component = app.component })
    }

    CompositionLocalProvider(LocalGlass provides glassK) {
        Box(Modifier.fillMaxSize().wallpaper(base)) {
            if (bgImg != null) {
                Image(bgImg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.12f)))
            }
            val front: @Composable () -> Unit = {
                if (cutImg != null) {
                    Image(cutImg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else if (cfg.wall == 0) {
                    HillsLayer(base)
                }
            }
            if (!cfg.depth) front()
            if (screen == 0) ClockLayer(theme, cfg)
            if (cfg.depth) front()
            Row(Modifier.fillMaxSize().padding(12.dp)) {
                Column(Modifier.weight(1f).fillMaxHeight()) {
                    StatusBar(theme, cfg.h24)
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        when (screen) {
                            0 -> HomeScreen(theme, cfg, apps) { launchApp(it) }
                            1 -> AppsScreen(theme, cfg, apps) { launchApp(it) }
                            else -> SettingsScreen(
                                theme, base, cfg, cutBmp != null,
                                { try { picker.launch("image/*") } catch (e: Exception) { } },
                                { try { cutPicker.launch("image/*") } catch (e: Exception) { } },
                                {
                                    try { File(context.filesDir, "cutout.png").delete() } catch (e: Exception) { }
                                    cutBmp = null
                                }
                            )
                        }
                    }
                }
            }
            AnimatedVisibility(
                visible = panel,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = 88.dp),
                enter = fadeIn() + scaleIn(initialScale = 0.9f),
                exit = fadeOut() + scaleOut(targetScale = 0.9f)
            ) {
                ControlCenter(theme, screen, { screen = it }) { panel = false }
            }
            GlowBox(
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = 20.dp).size(54.dp),
                accent = theme.accent,
                shape = CircleShape,
                focusScale = 1.15f,
                fill = Color.Black.copy(alpha = 0.35f),
                onClick = { panel = !panel }
            ) {
                Ico(if (panel) Icons.Rounded.Close else Icons.Rounded.Menu, Color.White, 26.dp, Modifier.align(Alignment.Center))
            }
        }
    }
}

// ---------- status bar ----------

@Composable
fun StatusBar(theme: LTheme, h24: Boolean) {
    val context = LocalContext.current
    val now = rememberNow()
    var battery by remember { mutableStateOf(-1) }
    var expanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scl = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            battery = if (lvl >= 0 && scl > 0) lvl * 100 / scl else -1
            delay(30000)
        }
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Box(Modifier.weight(1f)) {
            Text(
                SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(now),
                color = theme.text.copy(alpha = 0.8f), fontSize = 13.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        GlowBox(
            modifier = Modifier.animateContentSize(),
            accent = theme.accent,
            shape = RoundedCornerShape(24.dp),
            focusScale = 1.05f,
            fill = Color.Black,
            onClick = { expanded = !expanded }
        ) {
            Column(
                Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(fmtTime(now, h24, false), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                if (expanded) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Ico(Icons.Rounded.Notifications, Color.White.copy(alpha = 0.8f), 14.dp)
                        Text("Notifications (demo)", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Ico(Icons.Rounded.MusicNote, Color.White.copy(alpha = 0.8f), 14.dp)
                        Text("Media (demo)", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    }
                }
            }
        }
        Box(Modifier.weight(1f), contentAlignment = Alignment.TopEnd) {
            Row(
                Modifier.glass(RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Ico(Icons.Rounded.Wifi, theme.text, 16.dp)
                if (battery >= 0) {
                    Ico(Icons.Rounded.BatteryFull, theme.text, 16.dp)
                    Text("$battery%", color = theme.text, fontSize = 13.sp)
                }
            }
        }
    }
}

// ---------- screens ----------

@Composable
fun HomeScreen(theme: LTheme, cfg: Cfg, apps: List<AppInfo>, onOpen: (AppInfo) -> Unit) {
    val ds = dockSize(cfg)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val posF = listOf(0.24f, 0.30f, 0.38f)[cfg.clockPos]
        val topSpace = maxOf(120.dp, maxHeight * posF + 70.dp)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(topSpace))
            if (cfg.widgets) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    InfoCard(Modifier.weight(1f), "Weather", "28°C Sunny (demo)", theme.text)
                    InfoCard(Modifier.weight(1f), "Notes", "Your note here (demo)", theme.text)
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(
                Modifier.glass(RoundedCornerShape(28.dp)).padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                apps.take(cfg.dockCount).forEach { app ->
                    GlowBox(
                        modifier = Modifier.size(ds),
                        accent = theme.accent,
                        shape = iconShape(cfg, ds),
                        focusScale = 1.45f,
                        lens = true,
                        onClick = { onOpen(app) }
                    ) {
                        AppIcon(app, cfg, theme.accent, ds)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
fun InfoCard(modifier: Modifier, title: String, line: String, color: Color) {
    Column(modifier.glass().padding(16.dp)) {
        Text(title, color = color, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text(line, color = color.copy(alpha = 0.7f), fontSize = 14.sp)
    }
}

@Composable
fun AppsScreen(theme: LTheme, cfg: Cfg, apps: List<AppInfo>, onOpen: (AppInfo) -> Unit) {
    val gs = gridSize(cfg)
    Column(Modifier.fillMaxSize()) {
        Text("Apps", color = theme.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(gs + 36.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(8.dp)
        ) {
            items(apps) { app ->
                GlowBox(
                    accent = theme.accent,
                    shape = RoundedCornerShape(18.dp),
                    focusScale = 1.1f,
                    fill = Color.White.copy(alpha = 0.08f),
                    lens = true,
                    onClick = { onOpen(app) }
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        AppIcon(app, cfg, theme.accent, gs)
                        if (cfg.labels) {
                            Spacer(Modifier.height(6.dp))
                            Text(app.label, color = theme.text, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChipRow(title: String, options: List<String>, selected: Int, theme: LTheme, onSelect: (Int) -> Unit) {
    Text(title, color = theme.text.copy(alpha = 0.8f), fontSize = 14.sp)
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        options.forEachIndexed { i, name ->
            GlowBox(
                accent = theme.accent,
                shape = RoundedCornerShape(16.dp),
                focusScale = 1.08f,
                fill = if (i == selected) theme.accent.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.14f),
                onClick = { onSelect(i) }
            ) {
                Text(
                    name, color = theme.text, fontSize = 15.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                )
            }
        }
    }
}

@Composable
fun ActionRow(label: String, theme: LTheme, active: Boolean = false, onClick: () -> Unit) {
    GlowBox(
        modifier = Modifier.fillMaxWidth(),
        accent = theme.accent,
        shape = RoundedCornerShape(16.dp),
        focusScale = 1.03f,
        fill = if (active) theme.accent.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.14f),
        onClick = onClick
    ) {
        Text(label, color = theme.text, fontSize = 16.sp, modifier = Modifier.padding(16.dp))
    }
}

@Composable
fun SettingsScreen(
    theme: LTheme,
    base: LTheme,
    cfg: Cfg,
    hasCut: Boolean,
    onPickImage: () -> Unit,
    onPickCut: () -> Unit,
    onRemoveCut: () -> Unit
) {
    val context = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", color = theme.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        ChipRow("Theme", Themes.map { it.name }, cfg.themeIdx, theme) { cfg.change { themeIdx = it } }

        Text("Wallpaper", color = theme.text.copy(alpha = 0.8f), fontSize = 14.sp)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            WallpaperNames.forEachIndexed { i, name ->
                GlowBox(
                    modifier = if (cfg.wall == i) Modifier.border(3.dp, Color.White, RoundedCornerShape(14.dp)) else Modifier,
                    accent = theme.accent,
                    shape = RoundedCornerShape(14.dp),
                    focusScale = 1.08f,
                    onClick = { cfg.change { wall = i } }
                ) {
                    Box(Modifier.size(width = 120.dp, height = 72.dp).wallpaper(base)) {
                        if (i == 0) {
                            Canvas(Modifier.fillMaxSize()) { drawHills(base) }
                        } else {
                            val b = rememberRes(WallRes[i], 8)
                            val c = rememberRes(CutRes[i], 8)
                            if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            if (c != null) Image(c, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                        Text(
                            name, color = Color.White, fontSize = 12.sp,
                            modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                        )
                    }
                }
            }
        }
        ActionRow(
            if (cfg.wall < 0) "My wallpaper (active) - choose another" else "Choose my own wallpaper from device",
            theme, cfg.wall < 0, onPickImage
        )
        ActionRow(
            if (hasCut) "Cutout PNG added - choose another" else "Choose cutout PNG (clock goes behind it)",
            theme, hasCut, onPickCut
        )
        if (hasCut) ActionRow("Remove my cutout", theme, false, onRemoveCut)
        ToggleRow("Clock behind subject (depth effect)", cfg.depth, theme.accent, theme.text) { cfg.change { depth = !depth } }

        ChipRow("Clock style", listOf("Tall glass", "Normal"), cfg.clockStyle, theme) { cfg.change { clockStyle = it } }
        ChipRow("Clock position", listOf("Higher", "Default", "Lower"), cfg.clockPos, theme) { cfg.change { clockPos = it } }
        ChipRow("Clock size", listOf("Small", "Medium", "Large"), cfg.clockSize, theme) { cfg.change { clockSize = it } }

        ChipRow("Icon style", listOf("Glass", "Glass tinted", "Original"), cfg.iconStyle, theme) { cfg.change { iconStyle = it } }
        ChipRow("Icon shape", listOf("Squircle", "Circle"), cfg.iconShape, theme) { cfg.change { iconShape = it } }
        ChipRow("Icon size", listOf("Small", "Medium", "Large"), cfg.iconSize, theme) { cfg.change { iconSize = it } }
        ChipRow("Glass strength", listOf("Low", "Medium", "High"), cfg.glass, theme) { cfg.change { glass = it } }
        ChipRow("Dock apps", listOf("4", "5", "6", "7"), cfg.dockCount - 4, theme) { cfg.change { dockCount = it + 4 } }
        ToggleRow("Show app names", cfg.labels, theme.accent, theme.text) { cfg.change { labels = !labels } }
        ToggleRow("Show widgets on home", cfg.widgets, theme.accent, theme.text) { cfg.change { widgets = !widgets } }
        ToggleRow("24-hour clock", cfg.h24, theme.accent, theme.text) { cfg.change { h24 = !h24 } }
        ToggleRow("Show seconds", cfg.seconds, theme.accent, theme.text) { cfg.change { seconds = !seconds } }
        ActionRow("Open Android settings", theme) { safeStart(context, Intent(Settings.ACTION_SETTINGS)) }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun ToggleRow(label: String, on: Boolean, accent: Color, color: Color, onToggle: () -> Unit) {
    GlowBox(
        modifier = Modifier.fillMaxWidth(),
        accent = accent,
        shape = RoundedCornerShape(16.dp),
        focusScale = 1.03f,
        fill = Color.White.copy(alpha = 0.14f),
        onClick = onToggle
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = color, fontSize = 16.sp)
            Text(
                if (on) "ON" else "OFF",
                color = if (on) accent else color.copy(alpha = 0.5f),
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// ---------- control center ----------

@Composable
fun ControlCenter(theme: LTheme, screen: Int, onScreen: (Int) -> Unit, onClose: () -> Unit) {
    val context = LocalContext.current
    fun volume(direction: Int) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        } catch (e: Exception) {
        }
    }
    Column(
        Modifier
            .width(300.dp)
            .glass(RoundedCornerShape(28.dp))
            .background(Color.Black.copy(alpha = 0.25f))
            .heightIn(max = 380.dp)
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Control Center", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CCTile(Icons.Rounded.Home, "Home", Modifier.weight(1f), theme.accent, screen == 0) { onScreen(0); onClose() }
            CCTile(Icons.Rounded.Apps, "Apps", Modifier.weight(1f), theme.accent, screen == 1) { onScreen(1); onClose() }
            CCTile(Icons.Rounded.SettingsIcon, "Settings", Modifier.weight(1f), theme.accent, screen == 2) { onScreen(2); onClose() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CCTile(Icons.Rounded.Wifi, "Wi-Fi", Modifier.weight(1f), theme.accent) { safeStart(context, Intent(Settings.ACTION_WIFI_SETTINGS)) }
            CCTile(Icons.Rounded.Bluetooth, "Bluetooth", Modifier.weight(1f), theme.accent) { safeStart(context, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CCTile(Icons.Rounded.DesktopWindows, "Display", Modifier.weight(1f), theme.accent) { safeStart(context, Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
            CCTile(Icons.Rounded.VolumeUp, "Sound", Modifier.weight(1f), theme.accent) { safeStart(context, Intent(Settings.ACTION_SOUND_SETTINGS)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CCTile(Icons.Rounded.VolumeDown, "Vol -", Modifier.weight(1f), theme.accent) { volume(AudioManager.ADJUST_LOWER) }
            CCTile(Icons.Rounded.VolumeUp, "Vol +", Modifier.weight(1f), theme.accent) { volume(AudioManager.ADJUST_RAISE) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CCTile(Icons.Rounded.SettingsIcon, "Android", Modifier.weight(1f), theme.accent) { safeStart(context, Intent(Settings.ACTION_SETTINGS)) }
            CCTile(Icons.Rounded.Close, "Close", Modifier.weight(1f), theme.accent) { onClose() }
        }
    }
}

@Composable
fun CCTile(icon: ImageVector, label: String, modifier: Modifier, accent: Color, selected: Boolean = false, onClick: () -> Unit) {
    GlowBox(
        modifier = modifier.height(52.dp),
        accent = accent,
        shape = RoundedCornerShape(18.dp),
        focusScale = 1.06f,
        fill = if (selected) accent.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.18f),
        onClick = onClick
    ) {
        Column(
            Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Ico(icon, Color.White, 22.dp)
            Text(label, color = Color.White, fontSize = 12.sp)
        }
    }
}
